import './App.css'
import Dashboard from './Pages/lecturer_Dashbaord';

function App() {
  return (
    <Dashboard/>
  )
}

export default App;
