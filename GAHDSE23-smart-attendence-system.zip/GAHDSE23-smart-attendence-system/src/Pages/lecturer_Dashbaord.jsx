import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Dashboard.css';
import { Calendar, Clock, UserCheck, LogOut } from 'lucide-react';

const Dashboard = () => {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navigation Bar */}
      <nav className="navbar navbar-expand-lg navbar-custom shadow">
        <div className="container-fluid px-4">
          <a className="navbar-brand" href="#">
            <img src="/logo.jpg" alt="Logo" />
          </a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav mx-auto">
              <li className="nav-item">
                <a className="nav-link active" href="#">Home</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">Profile</a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="#">Services</a>
              </li>
            </ul>
            <button className="btn btn-outline-light d-flex align-items-center gap-2">
              <LogOut size={18} />
              <span>Logout</span>
            </button>
          </div>
        </div>
      </nav>



      {/* Main Content */}
      <div className="container py-5">
        <div className="row mb-4">
          <div className="col">
            <h1 className="mb-0 fw-bold">Attendance Dashboard</h1>
            <p className="text-muted">Monitor and manage attendance records</p>
          </div>
        </div>

        <div className="row">
          {/* Card 1 - Attendance Records */}
          <div className="col-md-6 mb-4">
            <div className="card border-0 shadow-sm h-100">
              <div className="card-body d-flex flex-column">
                <div className="d-flex align-items-center mb-4">
                  <div className="rounded-full bg-blue-100 p-3 me-3">
                    <Calendar size={24} className="text-blue-600" />
                  </div>
                  <h5 className="card-title mb-0 fw-bold">Attendance Records</h5>
                </div>
                <p className="card-text text-muted mb-4">
                  View and analyze past attendance data. Generate reports and track attendance patterns over time.
                </p>
                <div className="mt-auto">
                  <button className="btn btn-primary d-flex align-items-center gap-2 px-4">
                    <Clock size={18} />
                    <span>View Attendance Records</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Card 2 - Mark Attendance */}
          <div className="col-md-6 mb-4">
            <div className="card border-0 shadow-sm h-100 bg-gradient-to-br from-blue-50 to-white">
              <div className="card-body d-flex flex-column">
                <div className="d-flex align-items-center mb-4">
                  <div className="rounded-full bg-green-100 p-3 me-3">
                    <UserCheck size={24} className="text-green-600" />
                  </div>
                  <h5 className="card-title mb-0 fw-bold">Mark Attendance</h5>
                </div>
                <p className="card-text text-muted mb-4">
                  Quickly mark attendance for individuals or groups. Check in/out with just a single click.
                </p>
                <div className="mt-auto">
                  <button className="btn btn-success d-flex align-items-center gap-2 px-4">
                    <UserCheck size={18} />
                    <span>Mark Attendance</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;